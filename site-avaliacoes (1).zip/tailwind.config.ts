import type { Config } from "tailwindcss"

const config: Config = {
  darkMode: ["class"],
  content: ["./pages/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./app/**/*.{ts,tsx}", "./src/**/*.{ts,tsx}", "*.{js,ts,jsx,tsx,mdx}"],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(30, 20%, 85%)",
        input: "hsl(30, 20%, 85%)",
        ring: "hsl(30, 40%, 60%)",
        background: "hsl(30, 25%, 95%)",
        foreground: "hsl(30, 10%, 20%)",
        primary: {
          DEFAULT: "hsl(30, 40%, 65%)",
          foreground: "hsl(30, 5%, 15%)",
        },
        secondary: {
          DEFAULT: "hsl(30, 15%, 88%)",
          foreground: "hsl(30, 10%, 25%)",
        },
        destructive: {
          DEFAULT: "hsl(0, 84%, 60%)",
          foreground: "hsl(0, 0%, 98%)",
        },
        muted: {
          DEFAULT: "hsl(30, 20%, 90%)",
          foreground: "hsl(30, 8%, 45%)",
        },
        accent: {
          DEFAULT: "hsl(30, 20%, 88%)",
          foreground: "hsl(30, 10%, 25%)",
        },
        popover: {
          DEFAULT: "hsl(30, 25%, 95%)",
          foreground: "hsl(30, 10%, 20%)",
        },
        card: {
          DEFAULT: "hsl(30, 25%, 95%)",
          foreground: "hsl(30, 10%, 20%)",
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
} satisfies Config

export default config
