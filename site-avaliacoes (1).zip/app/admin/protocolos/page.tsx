"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, FileText, Plus, Save, TrendingUp } from 'lucide-react'
import Link from "next/link"

const protocolos = [
  {
    id: 1,
    crianca: "Ana Silva",
    protocolo: "VB-MAPP",
    data: "2024-01-20",
    responsavel: "Dr. Maria Silva",
    areas: [
      { nome: "Mando", pontuacao: 85, maximo: 100 },
      { nome: "Tato", pontuacao: 70, maximo: 100 },
      { nome: "Ecoico", pontuacao: 60, maximo: 100 },
      { nome: "Intraverbal", pontuacao: 45, maximo: 100 },
    ],
    observacoes: "Progresso significativo em mandos. Necessário trabalhar mais intraverbais.",
  },
  {
    id: 2,
    crianca: "Pedro Santos",
    protocolo: "ABLLS-R",
    data: "2024-01-18",
    responsavel: "Dra. Carla Oliveira",
    areas: [
      { nome: "Linguagem Receptiva", pontuacao: 75, maximo: 100 },
      { nome: "Linguagem Expressiva", pontuacao: 65, maximo: 100 },
      { nome: "Habilidades Sociais", pontuacao: 55, maximo: 100 },
      { nome: "Habilidades Acadêmicas", pontuacao: 40, maximo: 100 },
    ],
    observacoes: "Boa evolução na linguagem receptiva. Focar em habilidades sociais.",
  },
]

export default function ProtocolosPage() {
  const [mostrarFormulario, setMostrarFormulario] = useState(false)
  const [protocoloSelecionado, setProtocoloSelecionado] = useState<number | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const handleSalvarProtocolo = async () => {
    setIsLoading(true)
    await new Promise(resolve => setTimeout(resolve, 1000))
    alert("Protocolo salvo com sucesso!")
    setMostrarFormulario(false)
    setIsLoading(false)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/admin">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Voltar
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <FileText className="h-6 w-6 text-primary" />
                <h1 className="text-xl font-bold">Protocolos de Avaliação</h1>
              </div>
            </div>
            <Button onClick={() => setMostrarFormulario(!mostrarFormulario)}>
              <Plus className="h-4 w-4 mr-2" />
              Novo Protocolo
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Formulário de Protocolo */}
          {mostrarFormulario && (
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle>Novo Protocolo</CardTitle>
                  <CardDescription>Registre uma nova avaliação protocolar</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="crianca">Criança</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione a criança" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ana">Ana Silva</SelectItem>
                        <SelectItem value="pedro">Pedro Santos</SelectItem>
                        <SelectItem value="sofia">Sofia Oliveira</SelectItem>
                        <SelectItem value="lucas">Lucas Costa</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="protocolo">Tipo de Protocolo</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o protocolo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="vb-mapp">VB-MAPP</SelectItem>
                        <SelectItem value="ablls-r">ABLLS-R</SelectItem>
                        <SelectItem value="pep-3">PEP-3</SelectItem>
                        <SelectItem value="cars">CARS</SelectItem>
                        <SelectItem value="vineland">Vineland</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="responsavel">Responsável</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o responsável" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="maria">Dr. Maria Silva</SelectItem>
                        <SelectItem value="carla">Dra. Carla Oliveira</SelectItem>
                        <SelectItem value="roberto">Dr. Roberto Silva</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="data">Data da Avaliação</Label>
                    <Input id="data" type="date" />
                  </div>

                  <div>
                    <Label htmlFor="observacoes">Observações</Label>
                    <Textarea 
                      id="observacoes" 
                      placeholder="Observações gerais sobre a avaliação..." 
                      rows={3} 
                    />
                  </div>

                  <div className="flex gap-2 pt-4">
                    <Button 
                      className="flex-1" 
                      onClick={handleSalvarProtocolo}
                      disabled={isLoading}
                    >
                      <Save className="h-4 w-4 mr-2" />
                      {isLoading ? "Salvando..." : "Salvar"}
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => setMostrarFormulario(false)}
                      className="flex-1"
                    >
                      Cancelar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Lista de Protocolos */}
          <div className={mostrarFormulario ? "lg:col-span-2" : "lg:col-span-3"}>
            <div className="space-y-6">
              {protocolos.map((protocolo) => (
                <Card key={protocolo.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="flex items-center space-x-2">
                          <span>{protocolo.crianca}</span>
                          <Badge variant="outline">{protocolo.protocolo}</Badge>
                        </CardTitle>
                        <CardDescription>
                          Avaliado por {protocolo.responsavel} em {new Date(protocolo.data).toLocaleDateString("pt-BR")}
                        </CardDescription>
                      </div>
                      <Button variant="outline" size="sm">
                        <TrendingUp className="h-4 w-4 mr-2" />
                        Ver Evolução
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {/* Áreas Avaliadas */}
                      <div>
                        <h4 className="font-semibold mb-3">Áreas Avaliadas:</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {protocolo.areas.map((area, index) => (
                            <div key={index} className="space-y-2">
                              <div className="flex justify-between items-center">
                                <span className="text-sm font-medium">{area.nome}</span>
                                <span className="text-sm text-muted-foreground">
                                  {area.pontuacao}/{area.maximo}
                                </span>
                              </div>
                              <Progress 
                                value={(area.pontuacao / area.maximo) * 100} 
                                className="h-2" 
                              />
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Observações */}
                      <div>
                        <h4 className="font-semibold mb-2">Observações:</h4>
                        <p className="text-sm text-muted-foreground">{protocolo.observacoes}</p>
                      </div>

                      {/* Pontuação Geral */}
                      <div className="border-t pt-4">
                        <div className="flex items-center justify-between">
                          <span className="font-semibold">Pontuação Geral:</span>
                          <div className="text-right">
                            <div className="text-2xl font-bold text-primary">
                              {Math.round(protocolo.areas.reduce((acc, area) => acc + (area.pontuacao / area.maximo), 0) / protocolo.areas.length * 100)}%
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {protocolo.areas.reduce((acc, area) => acc + area.pontuacao, 0)} / {protocolo.areas.reduce((acc, area) => acc + area.maximo, 0)} pontos
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
