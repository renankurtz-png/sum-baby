"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Search, Filter, Users, Calendar, TrendingUp, Eye, Settings, UserPlus, User, FileText } from 'lucide-react'
import Link from "next/link"

const estatisticas = [
  {
    titulo: "Total de Crianças",
    valor: "24",
    mudanca: "+3",
    periodo: "Este mês",
    icone: Users,
  },
  {
    titulo: "Atendimentos Hoje",
    valor: "12",
    mudanca: "+2",
    periodo: "Agendados",
    icone: Calendar,
  },
  {
    titulo: "Taxa de Progresso",
    valor: "87%",
    mudanca: "+5%",
    periodo: "Média geral",
    icone: TrendingUp,
  },
  {
    titulo: "Sessões Realizadas",
    valor: "156",
    mudanca: "+18",
    periodo: "Esta semana",
    icone: Eye,
  },
]

const todasCriancas = [
  {
    id: 1,
    nome: "Ana Silva",
    idade: 5,
    diagnostico: "TEA Leve",
    dataInicio: "2024-01-15",
    terapeutas: ["Dr. Maria", "Dra. João"],
    progresso: "Excelente",
    proximaConsulta: "2024-01-25",
    foto: "/placeholder.svg?height=60&width=60",
    ativo: true,
    ultimaAvaliacao: 4.8,
    sessoesMes: 12,
  },
  {
    id: 2,
    nome: "Pedro Santos",
    idade: 7,
    diagnostico: "TEA Moderado",
    dataInicio: "2024-01-10",
    terapeutas: ["Dra. Carla", "Dr. Paulo"],
    progresso: "Bom",
    proximaConsulta: "2024-01-26",
    foto: "/placeholder.svg?height=60&width=60",
    ativo: true,
    ultimaAvaliacao: 4.2,
    sessoesMes: 10,
  },
  {
    id: 3,
    nome: "Sofia Oliveira",
    idade: 4,
    diagnostico: "TEA Leve",
    dataInicio: "2024-01-08",
    terapeutas: ["Dr. Maria", "Dra. Ana"],
    progresso: "Muito Bom",
    proximaConsulta: "2024-01-27",
    foto: "/placeholder.svg?height=60&width=60",
    ativo: true,
    ultimaAvaliacao: 4.6,
    sessoesMes: 14,
  },
  {
    id: 4,
    nome: "Lucas Costa",
    idade: 6,
    diagnostico: "TEA Severo",
    dataInicio: "2024-01-05",
    terapeutas: ["Dr. Roberto", "Dra. Lucia"],
    progresso: "Regular",
    proximaConsulta: "2024-01-28",
    foto: "/placeholder.svg?height=60&width=60",
    ativo: false,
    ultimaAvaliacao: 3.8,
    sessoesMes: 8,
  },
  {
    id: 5,
    nome: "Mariana Ferreira",
    idade: 3,
    diagnostico: "Atraso Desenvolvimento",
    dataInicio: "2024-01-12",
    terapeutas: ["Dra. Ana", "Dr. Carlos"],
    progresso: "Bom",
    proximaConsulta: "2024-01-29",
    foto: "/placeholder.svg?height=60&width=60",
    ativo: true,
    ultimaAvaliacao: 4.1,
    sessoesMes: 11,
  },
]

export default function AdminPage() {
  const [filtroNome, setFiltroNome] = useState("")
  const [filtroStatus, setFiltroStatus] = useState("todos-status")
  const [filtroProgresso, setFiltroProgresso] = useState("todos-progressos")
  const [filtroTerapeuta, setFiltroTerapeuta] = useState("todos-terapeutas")

  const criancasFiltradas = todasCriancas.filter(crianca => {
    const matchNome = crianca.nome.toLowerCase().includes(filtroNome.toLowerCase())
    const matchStatus = filtroStatus === "" || filtroStatus === "todos-status" || (filtroStatus === "ativo" ? crianca.ativo : !crianca.ativo)
    const matchProgresso = filtroProgresso === "" || filtroProgresso === "todos-progressos" || crianca.progresso === filtroProgresso
    const matchTerapeuta = filtroTerapeuta === "" || filtroTerapeuta === "todos-terapeutas" || crianca.terapeutas.some(t => t.includes(filtroTerapeuta))
    
    return matchNome && matchStatus && matchProgresso && matchTerapeuta
  })

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Voltar
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <Settings className="h-6 w-6 text-primary" />
                <h1 className="text-xl font-bold">Painel Administrativo</h1>
              </div>
            </div>
            <Link href="/criancas/cadastrar">
              <Button>
                <UserPlus className="h-4 w-4 mr-2" />
                Nova Criança
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Estatísticas Gerais */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {estatisticas.map((stat, index) => {
            const IconComponent = stat.icone
            return (
              <Card key={index}>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <CardDescription>{stat.titulo}</CardDescription>
                    <IconComponent className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <CardTitle className="text-2xl">{stat.valor}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center space-x-2 text-sm">
                    <Badge variant="default" className="text-xs">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      {stat.mudanca}
                    </Badge>
                    <span className="text-muted-foreground">{stat.periodo}</span>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Links Rápidos */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Link href="/admin/profissionais">
            <Card className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="flex items-center justify-center p-6">
                <div className="text-center">
                  <User className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <h3 className="font-semibold">Profissionais</h3>
                  <p className="text-sm text-muted-foreground">Gerenciar equipe</p>
                </div>
              </CardContent>
            </Card>
          </Link>
          
          <Link href="/admin/protocolos">
            <Card className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="flex items-center justify-center p-6">
                <div className="text-center">
                  <FileText className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <h3 className="font-semibold">Protocolos</h3>
                  <p className="text-sm text-muted-foreground">Avaliações protocolares</p>
                </div>
              </CardContent>
            </Card>
          </Link>
          
          <Link href="/criancas/cadastrar">
            <Card className="hover:shadow-md transition-shadow cursor-pointer">
              <CardContent className="flex items-center justify-center p-6">
                <div className="text-center">
                  <UserPlus className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <h3 className="font-semibold">Nova Criança</h3>
                  <p className="text-sm text-muted-foreground">Cadastrar criança</p>
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>

        {/* Filtros */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Filtros</CardTitle>
            <CardDescription>Filtre as crianças por diferentes critérios</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input 
                  placeholder="Buscar por nome..." 
                  className="pl-10" 
                  value={filtroNome}
                  onChange={(e) => setFiltroNome(e.target.value)}
                />
              </div>
              <Select value={filtroStatus} onValueChange={setFiltroStatus}>
                <SelectTrigger>
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos-status">Todos</SelectItem>
                  <SelectItem value="ativo">Ativo</SelectItem>
                  <SelectItem value="inativo">Inativo</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filtroProgresso} onValueChange={setFiltroProgresso}>
                <SelectTrigger>
                  <SelectValue placeholder="Progresso" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos-progressos">Todos</SelectItem>
                  <SelectItem value="Excelente">Excelente</SelectItem>
                  <SelectItem value="Muito Bom">Muito Bom</SelectItem>
                  <SelectItem value="Bom">Bom</SelectItem>
                  <SelectItem value="Regular">Regular</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filtroTerapeuta} onValueChange={setFiltroTerapeuta}>
                <SelectTrigger>
                  <SelectValue placeholder="Terapeuta" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos-terapeutas">Todos</SelectItem>
                  <SelectItem value="Maria">Dr. Maria</SelectItem>
                  <SelectItem value="Carla">Dra. Carla</SelectItem>
                  <SelectItem value="Roberto">Dr. Roberto</SelectItem>
                  <SelectItem value="João">Dra. João</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" onClick={() => {
                setFiltroNome("")
                setFiltroStatus("todos-status")
                setFiltroProgresso("todos-progressos")
                setFiltroTerapeuta("todos-terapeutas")
              }}>
                <Filter className="h-4 w-4 mr-2" />
                Limpar
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Lista Completa de Crianças */}
        <Card>
          <CardHeader>
            <CardTitle>Todas as Crianças ({criancasFiltradas.length})</CardTitle>
            <CardDescription>Visão geral de todas as crianças cadastradas na clínica</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {criancasFiltradas.map((crianca) => (
                <div key={crianca.id} className="border rounded-lg p-4 hover:bg-muted/50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <img
                        src={crianca.foto || "/placeholder.svg"}
                        alt={crianca.nome}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                      
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <span className="font-semibold">{crianca.nome}</span>
                          <Badge variant={crianca.ativo ? "default" : "secondary"}>
                            {crianca.ativo ? "Ativo" : "Inativo"}
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-muted-foreground">
                          <div>
                            <span className="font-medium">Idade:</span> {crianca.idade} anos
                          </div>
                          <div>
                            <span className="font-medium">Diagnóstico:</span> {crianca.diagnostico}
                          </div>
                          <div>
                            <span className="font-medium">Progresso:</span> 
                            <Badge variant={
                              crianca.progresso === "Excelente" ? "default" :
                              crianca.progresso === "Muito Bom" ? "default" :
                              crianca.progresso === "Bom" ? "secondary" : "outline"
                            } className="ml-1 text-xs">
                              {crianca.progresso}
                            </Badge>
                          </div>
                          <div>
                            <span className="font-medium">Sessões/mês:</span> {crianca.sessoesMes}
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-4 mt-2 text-sm text-muted-foreground">
                          <div>
                            <span className="font-medium">Terapeutas:</span> {crianca.terapeutas.join(", ")}
                          </div>
                          <div>
                            <span className="font-medium">Última avaliação:</span> {crianca.ultimaAvaliacao}/5
                          </div>
                          <div>
                            <span className="font-medium">Próxima consulta:</span> 
                            {new Date(crianca.proximaConsulta).toLocaleDateString("pt-BR")}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col space-y-2">
                      <Link href={`/criancas/${crianca.id}`}>
                        <Button variant="outline" size="sm" className="w-full">
                          <Eye className="h-4 w-4 mr-1" />
                          Ver
                        </Button>
                      </Link>
                      <Link href={`/atividades?crianca=${crianca.id}`}>
                        <Button size="sm" className="w-full">
                          Atividades
                        </Button>
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {criancasFiltradas.length === 0 && (
              <div className="text-center py-12">
                <p className="text-muted-foreground">Nenhuma criança encontrada com os filtros aplicados.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
