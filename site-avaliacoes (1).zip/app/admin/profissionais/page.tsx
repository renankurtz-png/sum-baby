"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Plus, Edit, Trash2, User, Search } from 'lucide-react'
import Link from "next/link"

const profissionais = [
  {
    id: 1,
    nome: "Dr. Maria Silva",
    classificacao: "AT",
    especialidade: "Terapia ABA",
    registro: "CRP 12345",
    telefone: "(11) 99999-9999",
    email: "maria@sunbaby.com",
    ativo: true,
  },
  {
    id: 2,
    nome: "Dra. Carla Oliveira",
    classificacao: "Supervisora",
    especialidade: "Análise do Comportamento",
    registro: "CRP 67890",
    telefone: "(11) 88888-8888",
    email: "carla@sunbaby.com",
    ativo: true,
  },
  {
    id: 3,
    nome: "Dr. Roberto Silva",
    classificacao: "TO",
    especialidade: "Terapia Ocupacional",
    registro: "CREFITO 11111",
    telefone: "(11) 77777-7777",
    email: "roberto@sunbaby.com",
    ativo: true,
  },
  {
    id: 4,
    nome: "Dra. Ana Santos",
    classificacao: "Fono",
    especialidade: "Fonoaudiologia",
    registro: "CRFa 22222",
    telefone: "(11) 66666-6666",
    email: "ana@sunbaby.com",
    ativo: false,
  },
]

export default function ProfissionaisPage() {
  const [mostrarFormulario, setMostrarFormulario] = useState(false)
  const [editando, setEditando] = useState<number | null>(null)
  const [filtroNome, setFiltroNome] = useState("")
  const [filtroClassificacao, setFiltroClassificacao] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const profissionaisFiltrados = profissionais.filter(prof => {
    const matchNome = filtroNome === "" || prof.nome.toLowerCase().includes(filtroNome.toLowerCase())
    const matchClassificacao = filtroClassificacao === "" || prof.classificacao === filtroClassificacao
    return matchNome && matchClassificacao
  })

  const handleCadastrar = async () => {
    setIsLoading(true)
    await new Promise(resolve => setTimeout(resolve, 1000))
    alert("Profissional cadastrado com sucesso!")
    setMostrarFormulario(false)
    setIsLoading(false)
  }

  const handleDeletar = (id: number, nome: string) => {
    if (confirm(`Tem certeza que deseja deletar ${nome}?`)) {
      alert(`Profissional ${nome} deletado!`)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/admin">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Voltar
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <User className="h-6 w-6 text-primary" />
                <h1 className="text-xl font-bold">Profissionais</h1>
              </div>
            </div>
            <Button onClick={() => setMostrarFormulario(!mostrarFormulario)}>
              <Plus className="h-4 w-4 mr-2" />
              Novo Profissional
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Formulário */}
          {mostrarFormulario && (
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle>Cadastrar Profissional</CardTitle>
                  <CardDescription>Adicione um novo profissional à equipe</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="nome">Nome Completo</Label>
                    <Input id="nome" placeholder="Dr. João Silva" />
                  </div>

                  <div>
                    <Label htmlFor="classificacao">Classificação</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione a classificação" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="AT">AT (Acompanhante Terapêutico)</SelectItem>
                        <SelectItem value="Supervisora">Supervisora</SelectItem>
                        <SelectItem value="TO">TO (Terapeuta Ocupacional)</SelectItem>
                        <SelectItem value="Fono">Fonoaudióloga</SelectItem>
                        <SelectItem value="Psicologa">Psicóloga</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="especialidade">Especialidade</Label>
                    <Input id="especialidade" placeholder="Terapia ABA" />
                  </div>

                  <div>
                    <Label htmlFor="registro">Registro Profissional</Label>
                    <Input id="registro" placeholder="CRP 12345" />
                  </div>

                  <div>
                    <Label htmlFor="telefone">Telefone</Label>
                    <Input id="telefone" placeholder="(11) 99999-9999" />
                  </div>

                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" placeholder="profissional@sunbaby.com" />
                  </div>

                  <div className="flex gap-2 pt-4">
                    <Button 
                      className="flex-1" 
                      onClick={handleCadastrar}
                      disabled={isLoading}
                    >
                      {isLoading ? "Cadastrando..." : "Cadastrar"}
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => setMostrarFormulario(false)}
                      className="flex-1"
                    >
                      Cancelar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Lista de Profissionais */}
          <div className={mostrarFormulario ? "lg:col-span-2" : "lg:col-span-3"}>
            {/* Filtros */}
            <Card className="mb-6">
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input 
                      placeholder="Buscar por nome..." 
                      className="pl-10" 
                      value={filtroNome}
                      onChange={(e) => setFiltroNome(e.target.value)}
                    />
                  </div>
                  <Select value={filtroClassificacao} onValueChange={setFiltroClassificacao}>
                    <SelectTrigger>
                      <SelectValue placeholder="Classificação" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Todas</SelectItem>
                      <SelectItem value="AT">AT</SelectItem>
                      <SelectItem value="Supervisora">Supervisora</SelectItem>
                      <SelectItem value="TO">TO</SelectItem>
                      <SelectItem value="Fono">Fono</SelectItem>
                      <SelectItem value="Psicologa">Psicóloga</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline" onClick={() => {
                    setFiltroNome("")
                    setFiltroClassificacao("")
                  }}>
                    Limpar Filtros
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Equipe ({profissionaisFiltrados.length})</CardTitle>
                <CardDescription>Profissionais cadastrados na clínica</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {profissionaisFiltrados.map((profissional) => (
                    <div key={profissional.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <span className="font-semibold">{profissional.nome}</span>
                            <Badge variant={profissional.ativo ? "default" : "secondary"}>
                              {profissional.ativo ? "Ativo" : "Inativo"}
                            </Badge>
                            <Badge variant="outline">{profissional.classificacao}</Badge>
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-muted-foreground">
                            <div>
                              <span className="font-medium">Especialidade:</span> {profissional.especialidade}
                            </div>
                            <div>
                              <span className="font-medium">Registro:</span> {profissional.registro}
                            </div>
                            <div>
                              <span className="font-medium">Telefone:</span> {profissional.telefone}
                            </div>
                          </div>
                          
                          <div className="text-sm text-muted-foreground mt-1">
                            <span className="font-medium">Email:</span> {profissional.email}
                          </div>
                        </div>

                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Edit className="h-4 w-4 mr-1" />
                            Editar
                          </Button>
                          <Button 
                            variant="destructive" 
                            size="sm"
                            onClick={() => handleDeletar(profissional.id, profissional.nome)}
                          >
                            <Trash2 className="h-4 w-4 mr-1" />
                            Deletar
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {profissionaisFiltrados.length === 0 && (
                  <div className="text-center py-12">
                    <p className="text-muted-foreground">Nenhum profissional encontrado.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
