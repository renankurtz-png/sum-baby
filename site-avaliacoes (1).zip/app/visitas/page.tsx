import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Eye, ArrowLeft, Search, Calendar, MapPin, TrendingUp, Clock } from 'lucide-react'
import Link from "next/link"

const visitasRecentes = [
  {
    id: 1,
    local: "Sala de Terapia ABA",
    categoria: "Terapia",
    localizacao: "Clínica Infantil, Andar 2",
    dataVisita: "2024-01-18",
    duracao: "1h 30min",
    visitantes: 245,
    tendencia: "+12%",
    imagem: "/placeholder.svg?height=150&width=200",
  },
  {
    id: 2,
    local: "Sala de Integração Sensorial",
    categoria: "Especializada",
    localizacao: "Clínica Infantil, Andar 1",
    dataVisita: "2024-01-17",
    duracao: "45min",
    visitantes: 189,
    tendencia: "+8%",
    imagem: "/placeholder.svg?height=150&width=200",
  },
  {
    id: 3,
    local: "Espaço de Desenvolvimento Social",
    categoria: "Terapia",
    localizacao: "Clínica Infantil, Andar 2",
    dataVisita: "2024-01-16",
    duracao: "1h 15min",
    visitantes: 156,
    tendencia: "+25%",
    imagem: "/placeholder.svg?height=150&width=200",
  },
]

const estatisticas = [
  {
    titulo: "Total de Visitas",
    valor: "12,456",
    mudanca: "+15%",
    periodo: "Este mês",
  },
  {
    titulo: "Locais Visitados",
    valor: "1,234",
    mudanca: "+8%",
    periodo: "Este mês",
  },
  {
    titulo: "Tempo Médio",
    valor: "2h 45min",
    mudanca: "+12%",
    periodo: "Por visita",
  },
  {
    titulo: "Avaliações",
    valor: "3,456",
    mudanca: "+22%",
    periodo: "Este mês",
  },
]

export default function VisitasPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar
              </Button>
            </Link>
            <div className="flex items-center space-x-2">
              <Eye className="h-6 w-6 text-primary" />
              <h1 className="text-xl font-bold">Visitas</h1>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Estatísticas */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {estatisticas.map((stat, index) => (
            <Card key={index}>
              <CardHeader className="pb-2">
                <CardDescription>{stat.titulo}</CardDescription>
                <CardTitle className="text-2xl">{stat.valor}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-2 text-sm">
                  <Badge variant={stat.mudanca.startsWith("+") ? "default" : "destructive"} className="text-xs">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    {stat.mudanca}
                  </Badge>
                  <span className="text-muted-foreground">{stat.periodo}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Filtros e Busca */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input placeholder="Buscar visitas..." className="pl-10" />
              </div>
            </div>
            <Select>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Categoria" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todas</SelectItem>
                <SelectItem value="terapia">Terapia</SelectItem>
                <SelectItem value="especializada">Especializada</SelectItem>
                <SelectItem value="desenvolvimento">Desenvolvimento</SelectItem>
              </SelectContent>
            </Select>
            <Select>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Período" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="hoje">Hoje</SelectItem>
                <SelectItem value="semana">Esta semana</SelectItem>
                <SelectItem value="mes">Este mês</SelectItem>
                <SelectItem value="ano">Este ano</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Lista de Visitas */}
        <div className="space-y-4">
          <h3 className="text-2xl font-bold mb-6">Visitas Recentes</h3>

          {visitasRecentes.map((visita) => (
            <Card key={visita.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row gap-4">
                  <img
                    src={visita.imagem || "/placeholder.svg"}
                    alt={visita.local}
                    className="w-full md:w-32 h-24 object-cover rounded-lg"
                  />

                  <div className="flex-1">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
                      <div>
                        <h4 className="text-lg font-semibold">{visita.local}</h4>
                        <div className="flex items-center space-x-4 text-sm text-muted-foreground mt-1">
                          <div className="flex items-center">
                            <MapPin className="h-4 w-4 mr-1" />
                            {visita.localizacao}
                          </div>
                          <Badge variant="outline">{visita.categoria}</Badge>
                        </div>
                      </div>

                      <div className="flex items-center space-x-4 mt-2 md:mt-0">
                        <Badge variant={visita.tendencia.startsWith("+") ? "default" : "destructive"}>
                          <TrendingUp className="h-3 w-3 mr-1" />
                          {visita.tendencia}
                        </Badge>
                      </div>
                    </div>

                    <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                      <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-1" />
                          {new Date(visita.dataVisita).toLocaleDateString("pt-BR")}
                        </div>
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-1" />
                          {visita.duracao}
                        </div>
                        <div className="flex items-center">
                          <Eye className="h-4 w-4 mr-1" />
                          {visita.visitantes} visitantes
                        </div>
                      </div>

                      <Button variant="outline" size="sm" className="mt-2 md:mt-0 bg-transparent">
                        Ver Detalhes
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Paginação */}
        <div className="flex justify-center mt-12">
          <div className="flex items-center space-x-2">
            <Button variant="outline" disabled>
              Anterior
            </Button>
            <Button variant="outline" className="bg-primary text-primary-foreground">
              1
            </Button>
            <Button variant="outline">2</Button>
            <Button variant="outline">3</Button>
            <Button variant="outline">Próximo</Button>
          </div>
        </div>
      </div>
    </div>
  )
}
