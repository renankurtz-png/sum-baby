"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { ArrowLeft, Calendar, Phone, MapPin, Brain, TrendingUp, Activity } from 'lucide-react'
import Link from "next/link"

// Dados de exemplo para uma criança específica
const crianca = {
  id: 1,
  nome: "Ana Silva",
  idade: 5,
  dataNascimento: "2019-03-15",
  genero: "Feminino",
  diagnostico: "TEA Leve",
  dataInicio: "2024-01-15",
  terapeutas: ["Dr. Maria Silva", "Dra. João Santos"],
  progresso: "Excelente",
  proximaConsulta: "2024-01-25",
  foto: "/placeholder.svg?height=150&width=150",
  ativo: true,
  responsaveis: [
    { nome: "Carlos Silva", telefone: "(11) 99999-9999" },
    { nome: "Ana Santos", telefone: "(11) 88888-8888" }
  ],
  endereco: "Rua das Flores, 123 - São Paulo, SP",
  objetivos: "Desenvolver comunicação funcional, melhorar interação social e reduzir comportamentos repetitivos.",
  evolucao: [
    { area: "Comunicação", progresso: 85, meta: 90 },
    { area: "Interação Social", progresso: 70, meta: 80 },
    { area: "Comportamento", progresso: 75, meta: 85 },
    { area: "Autonomia", progresso: 60, meta: 75 },
  ],
  sessoes: [
    { data: "2024-01-20", tipo: "ABA", duracao: "1h", observacoes: "Ótimo progresso na comunicação" },
    { data: "2024-01-18", tipo: "Social", duracao: "45min", observacoes: "Interagiu bem com outras crianças" },
    { data: "2024-01-16", tipo: "Sensorial", duracao: "30min", observacoes: "Melhor regulação sensorial" },
  ]
}

export default function DetalheCriancaPage({ params }: { params: { id: string } }) {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Link href="/criancas">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar
              </Button>
            </Link>
            <h1 className="text-xl font-bold">Detalhes da Criança</h1>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Informações Básicas */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader className="text-center">
                <img
                  src={crianca.foto || "/placeholder.svg"}
                  alt={crianca.nome}
                  className="w-32 h-32 rounded-full object-cover mx-auto mb-4"
                />
                <CardTitle className="text-2xl">{crianca.nome}</CardTitle>
                <CardDescription>{crianca.idade} anos</CardDescription>
                <Badge variant={crianca.ativo ? "default" : "secondary"} className="mt-2">
                  {crianca.ativo ? "Ativo" : "Inativo"}
                </Badge>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm font-medium">Diagnóstico:</p>
                  <p className="text-sm text-muted-foreground">{crianca.diagnostico}</p>
                </div>
                
                <div>
                  <p className="text-sm font-medium">Data de Nascimento:</p>
                  <p className="text-sm text-muted-foreground">
                    {new Date(crianca.dataNascimento).toLocaleDateString("pt-BR")}
                  </p>
                </div>

                <div>
                  <p className="text-sm font-medium">Início do Tratamento:</p>
                  <p className="text-sm text-muted-foreground">
                    {new Date(crianca.dataInicio).toLocaleDateString("pt-BR")}
                  </p>
                </div>

                <div>
                  <p className="text-sm font-medium">Próxima Consulta:</p>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4 mr-1" />
                    {new Date(crianca.proximaConsulta).toLocaleDateString("pt-BR")}
                  </div>
                </div>

                <div>
                  <p className="text-sm font-medium">Terapeutas:</p>
                  <p className="text-sm text-muted-foreground">{crianca.terapeutas.join(", ")}</p>
                </div>

                <div className="pt-4 space-y-2">
                  <Link href={`/atividades?crianca=${crianca.id}`}>
                    <Button className="w-full" size="sm">
                      <Brain className="h-4 w-4 mr-2" />
                      Ver Atividades
                    </Button>
                  </Link>
                  <Link href={`/agenda?crianca=${crianca.id}`}>
                    <Button variant="outline" className="w-full" size="sm">
                      <Calendar className="h-4 w-4 mr-2" />
                      Agendar Consulta
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Evolução e Detalhes */}
          <div className="lg:col-span-2 space-y-6">
            {/* Progresso Geral */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2" />
                  Evolução por Área
                </CardTitle>
                <CardDescription>Progresso atual vs metas estabelecidas</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {crianca.evolucao.map((area, index) => (
                  <div key={index}>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium">{area.area}</span>
                      <span className="text-sm text-muted-foreground">
                        {area.progresso}% / {area.meta}%
                      </span>
                    </div>
                    <Progress value={area.progresso} className="h-2" />
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Sessões Recentes */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Activity className="h-5 w-5 mr-2" />
                  Sessões Recentes
                </CardTitle>
                <CardDescription>Últimas atividades realizadas</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {crianca.sessoes.map((sessao, index) => (
                    <div key={index} className="border-l-4 border-primary pl-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-medium">{sessao.tipo}</p>
                          <p className="text-sm text-muted-foreground">{sessao.observacoes}</p>
                        </div>
                        <div className="text-right text-sm text-muted-foreground">
                          <p>{new Date(sessao.data).toLocaleDateString("pt-BR")}</p>
                          <p>{sessao.duracao}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Informações de Contato */}
            <Card>
              <CardHeader>
                <CardTitle>Informações de Contato</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm font-medium">Responsáveis:</p>
                  {crianca.responsaveis.map((responsavel, index) => (
                    <div key={index} className="flex items-center justify-between mt-2">
                      <span className="text-sm">{responsavel.nome}</span>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Phone className="h-4 w-4 mr-1" />
                        {responsavel.telefone}
                      </div>
                    </div>
                  ))}
                </div>
                
                <div>
                  <p className="text-sm font-medium">Endereço:</p>
                  <div className="flex items-center text-sm text-muted-foreground mt-1">
                    <MapPin className="h-4 w-4 mr-1" />
                    {crianca.endereco}
                  </div>
                </div>

                <div>
                  <p className="text-sm font-medium">Objetivos Terapêuticos:</p>
                  <p className="text-sm text-muted-foreground mt-1">{crianca.objetivos}</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
