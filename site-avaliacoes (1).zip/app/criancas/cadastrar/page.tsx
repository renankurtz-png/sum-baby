"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Upload, X, ImageIcon } from 'lucide-react'
import Link from "next/link"

export default function CadastrarCriancaPage() {
  const [foto, setFoto] = useState<string>("")
  const [isLoading, setIsLoading] = useState(false)

  const handleFotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setFoto(URL.createObjectURL(file))
    }
  }

  const removeFoto = () => {
    setFoto("")
  }

  const handleCadastrar = async () => {
    setIsLoading(true)
    await new Promise(resolve => setTimeout(resolve, 1000))
    alert("Criança cadastrada com sucesso!")
    setIsLoading(false)
  }

  const handleSalvarRascunho = async () => {
    setIsLoading(true)
    await new Promise(resolve => setTimeout(resolve, 1000))
    alert("Rascunho salvo com sucesso!")
    setIsLoading(false)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Link href="/criancas">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar
              </Button>
            </Link>
            <h1 className="text-xl font-bold">Cadastrar Nova Criança</h1>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Dados da Criança</CardTitle>
              <CardDescription>Preencha as informações para cadastrar uma nova criança</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Foto */}
              <div>
                <Label>Foto da Criança</Label>
                <div className="mt-2">
                  {!foto ? (
                    <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-6 text-center">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFotoUpload}
                        className="hidden"
                        id="foto-upload"
                      />
                      <label htmlFor="foto-upload" className="cursor-pointer">
                        <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">Clique para adicionar foto</p>
                      </label>
                    </div>
                  ) : (
                    <div className="relative inline-block">
                      <img
                        src={foto || "/placeholder.svg"}
                        alt="Foto da criança"
                        className="w-32 h-32 rounded-full object-cover"
                      />
                      <button
                        onClick={removeFoto}
                        className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Informações Básicas */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="nome">Nome Completo</Label>
                  <Input id="nome" placeholder="Ex: Ana Silva Santos" />
                </div>
                <div>
                  <Label htmlFor="idade">Idade</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione a idade" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2">2 anos</SelectItem>
                      <SelectItem value="3">3 anos</SelectItem>
                      <SelectItem value="4">4 anos</SelectItem>
                      <SelectItem value="5">5 anos</SelectItem>
                      <SelectItem value="6">6 anos</SelectItem>
                      <SelectItem value="7">7 anos</SelectItem>
                      <SelectItem value="8">8 anos</SelectItem>
                      <SelectItem value="9">9 anos</SelectItem>
                      <SelectItem value="10">10 anos</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="dataNascimento">Data de Nascimento</Label>
                  <Input id="dataNascimento" type="date" />
                </div>
                <div>
                  <Label htmlFor="genero">Gênero</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione o gênero" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="masculino">Masculino</SelectItem>
                      <SelectItem value="feminino">Feminino</SelectItem>
                      <SelectItem value="outro">Outro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Informações Médicas */}
              <div>
                <Label htmlFor="diagnostico">Diagnóstico</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o diagnóstico" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tea-leve">TEA Leve</SelectItem>
                    <SelectItem value="tea-moderado">TEA Moderado</SelectItem>
                    <SelectItem value="tea-severo">TEA Severo</SelectItem>
                    <SelectItem value="atraso-desenvolvimento">Atraso no Desenvolvimento</SelectItem>
                    <SelectItem value="outro">Outro</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="observacoes">Observações Médicas</Label>
                <Textarea 
                  id="observacoes" 
                  placeholder="Informações adicionais sobre o diagnóstico, medicações, etc..." 
                  rows={3} 
                />
              </div>

              {/* Informações dos Responsáveis */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Responsáveis</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="responsavel1">Nome do Responsável 1</Label>
                    <Input id="responsavel1" placeholder="Nome completo" />
                  </div>
                  <div>
                    <Label htmlFor="telefone1">Telefone</Label>
                    <Input id="telefone1" placeholder="(11) 99999-9999" />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="responsavel2">Nome do Responsável 2</Label>
                    <Input id="responsavel2" placeholder="Nome completo (opcional)" />
                  </div>
                  <div>
                    <Label htmlFor="telefone2">Telefone</Label>
                    <Input id="telefone2" placeholder="(11) 99999-9999 (opcional)" />
                  </div>
                </div>

                <div>
                  <Label htmlFor="endereco">Endereço</Label>
                  <Input id="endereco" placeholder="Rua, número, bairro, cidade" />
                </div>
              </div>

              {/* Informações da Terapia */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Informações da Terapia</h3>
                
                <div>
                  <Label htmlFor="dataInicio">Data de Início</Label>
                  <Input id="dataInicio" type="date" />
                </div>

                <div>
                  <Label htmlFor="terapeutas">Terapeutas Responsáveis</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione os terapeutas" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="dr-maria">Dr. Maria Silva</SelectItem>
                      <SelectItem value="dra-joao">Dra. João Santos</SelectItem>
                      <SelectItem value="dra-carla">Dra. Carla Oliveira</SelectItem>
                      <SelectItem value="dr-paulo">Dr. Paulo Costa</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="objetivos">Objetivos Terapêuticos</Label>
                  <Textarea 
                    id="objetivos" 
                    placeholder="Descreva os principais objetivos para esta criança..." 
                    rows={3} 
                  />
                </div>
              </div>

              {/* Botões de Ação */}
              <div className="flex gap-4 pt-4">
                <Button 
                  className="flex-1" 
                  onClick={handleCadastrar}
                  disabled={isLoading}
                >
                  {isLoading ? "Cadastrando..." : "Cadastrar Criança"}
                </Button>
                <Button 
                  variant="outline" 
                  className="flex-1"
                  onClick={handleSalvarRascunho}
                  disabled={isLoading}
                >
                  {isLoading ? "Salvando..." : "Salvar Rascunho"}
                </Button>
                <Link href="/criancas">
                  <Button variant="destructive" className="flex-1">
                    Cancelar
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
