"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Search, Filter, Calendar, Users, Brain, Plus, Eye } from 'lucide-react'
import Link from "next/link"

const criancas = [
  {
    id: 1,
    nome: "Ana Silva",
    idade: 5,
    diagnostico: "TEA Leve",
    dataInicio: "2024-01-15",
    terapeutas: ["Dr. Maria", "Dra. João"],
    progresso: "Excelente",
    proximaConsulta: "2024-01-25",
    foto: "/placeholder.svg?height=100&width=100",
    ativo: true,
  },
  {
    id: 2,
    nome: "Pedro Santos",
    idade: 7,
    diagnostico: "TEA Moderado",
    dataInicio: "2024-01-10",
    terapeutas: ["Dra. Carla", "Dr. Paulo"],
    progresso: "Bom",
    proximaConsulta: "2024-01-26",
    foto: "/placeholder.svg?height=100&width=100",
    ativo: true,
  },
  {
    id: 3,
    nome: "Sofia Oliveira",
    idade: 4,
    diagnostico: "TEA Leve",
    dataInicio: "2024-01-08",
    terapeutas: ["Dr. Maria", "Dra. Ana"],
    progresso: "Muito Bom",
    proximaConsulta: "2024-01-27",
    foto: "/placeholder.svg?height=100&width=100",
    ativo: true,
  },
  {
    id: 4,
    nome: "Lucas Costa",
    idade: 6,
    diagnostico: "TEA Severo",
    dataInicio: "2024-01-05",
    terapeutas: ["Dr. Roberto", "Dra. Lucia"],
    progresso: "Regular",
    proximaConsulta: "2024-01-28",
    foto: "/placeholder.svg?height=100&width=100",
    ativo: false,
  },
]

export default function CriancasPage() {
  const [filtroNome, setFiltroNome] = useState("")
  const [filtroIdade, setFiltroIdade] = useState("todas-idades")
  const [filtroProgresso, setFiltroProgresso] = useState("todos-progressos")
  const [filtroStatus, setFiltroStatus] = useState("todos-status")

  const criancasFiltradas = criancas.filter(crianca => {
    const matchNome = crianca.nome.toLowerCase().includes(filtroNome.toLowerCase())
    const matchIdade = filtroIdade === "" || filtroIdade === "todas-idades" || crianca.idade.toString() === filtroIdade
    const matchProgresso = filtroProgresso === "" || filtroProgresso === "todos-progressos" || crianca.progresso === filtroProgresso
    const matchStatus = filtroStatus === "" || filtroStatus === "todos-status" || (filtroStatus === "ativo" ? crianca.ativo : !crianca.ativo)
    
    return matchNome && matchIdade && matchProgresso && matchStatus
  })

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Voltar
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <Users className="h-6 w-6 text-primary" />
                <h1 className="text-xl font-bold">Crianças Cadastradas</h1>
              </div>
            </div>
            <Link href="/criancas/cadastrar">
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Cadastrar Criança
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Filtros e Busca */}
        <div className="mb-8">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input 
                placeholder="Buscar por nome..." 
                className="pl-10" 
                value={filtroNome}
                onChange={(e) => setFiltroNome(e.target.value)}
              />
            </div>
            <Select value={filtroIdade} onValueChange={setFiltroIdade}>
              <SelectTrigger>
                <SelectValue placeholder="Idade" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas-idades">Todas</SelectItem>
                <SelectItem value="3">3 anos</SelectItem>
                <SelectItem value="4">4 anos</SelectItem>
                <SelectItem value="5">5 anos</SelectItem>
                <SelectItem value="6">6 anos</SelectItem>
                <SelectItem value="7">7 anos</SelectItem>
                <SelectItem value="8">8 anos</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filtroProgresso} onValueChange={setFiltroProgresso}>
              <SelectTrigger>
                <SelectValue placeholder="Progresso" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos-progressos">Todos</SelectItem>
                <SelectItem value="Excelente">Excelente</SelectItem>
                <SelectItem value="Muito Bom">Muito Bom</SelectItem>
                <SelectItem value="Bom">Bom</SelectItem>
                <SelectItem value="Regular">Regular</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filtroStatus} onValueChange={setFiltroStatus}>
              <SelectTrigger>
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos-status">Todos</SelectItem>
                <SelectItem value="ativo">Ativo</SelectItem>
                <SelectItem value="inativo">Inativo</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" onClick={() => {
              setFiltroNome("")
              setFiltroIdade("todas-idades")
              setFiltroProgresso("todos-progressos")
              setFiltroStatus("todos-status")
            }}>
              <Filter className="h-4 w-4 mr-2" />
              Limpar
            </Button>
          </div>
        </div>

        {/* Lista de Crianças */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {criancasFiltradas.map((crianca) => (
            <Card key={crianca.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center space-x-4">
                  <img
                    src={crianca.foto || "/placeholder.svg"}
                    alt={crianca.nome}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <CardTitle className="text-lg">{crianca.nome}</CardTitle>
                    <CardDescription>{crianca.idade} anos</CardDescription>
                  </div>
                  <Badge variant={crianca.ativo ? "default" : "secondary"}>
                    {crianca.ativo ? "Ativo" : "Inativo"}
                  </Badge>
                </div>
              </CardHeader>

              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm font-medium">Diagnóstico:</p>
                  <p className="text-sm text-muted-foreground">{crianca.diagnostico}</p>
                </div>
                
                <div>
                  <p className="text-sm font-medium">Progresso:</p>
                  <Badge variant={
                    crianca.progresso === "Excelente" ? "default" :
                    crianca.progresso === "Muito Bom" ? "default" :
                    crianca.progresso === "Bom" ? "secondary" : "outline"
                  }>
                    {crianca.progresso}
                  </Badge>
                </div>

                <div>
                  <p className="text-sm font-medium">Terapeutas:</p>
                  <p className="text-sm text-muted-foreground">{crianca.terapeutas.join(", ")}</p>
                </div>

                <div>
                  <p className="text-sm font-medium">Próxima Consulta:</p>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4 mr-1" />
                    {new Date(crianca.proximaConsulta).toLocaleDateString("pt-BR")}
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <Link href={`/criancas/${crianca.id}`} className="flex-1">
                    <Button variant="outline" size="sm" className="w-full">
                      <Eye className="h-4 w-4 mr-1" />
                      Ver Detalhes
                    </Button>
                  </Link>
                  <Link href={`/atividades?crianca=${crianca.id}`} className="flex-1">
                    <Button size="sm" className="w-full">
                      <Brain className="h-4 w-4 mr-1" />
                      Atividades
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {criancasFiltradas.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Nenhuma criança encontrada com os filtros aplicados.</p>
          </div>
        )}
      </div>
    </div>
  )
}
