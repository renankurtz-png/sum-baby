"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Calendar, Clock, Plus, User, Search, Filter, X } from 'lucide-react'
import Link from "next/link"

const agendamentos = [
  {
    id: 1,
    crianca: "Ana Silva",
    terapeuta: "Dr. Maria Silva",
    responsavel: "Carlos Silva",
    data: "2024-01-25",
    horario: "09:00",
    tipo: "ABA",
    status: "Agendado",
    duracao: "1h",
  },
  {
    id: 2,
    crianca: "Pedro Santos",
    terapeuta: "Dra. Carla Oliveira",
    responsavel: "Ana Santos",
    data: "2024-01-25",
    horario: "10:30",
    tipo: "Social",
    status: "Agendado",
    duracao: "45min",
  },
  {
    id: 3,
    crianca: "Sofia Oliveira",
    terapeuta: "Dr. Maria Silva",
    responsavel: "João Oliveira",
    data: "2024-01-26",
    horario: "14:00",
    tipo: "Comunicação",
    status: "Confirmado",
    duracao: "1h",
  },
  {
    id: 4,
    crianca: "Lucas Costa",
    terapeuta: "Dr. Roberto Silva",
    responsavel: "Maria Costa",
    data: "2024-01-27",
    horario: "09:30",
    tipo: "Sensorial",
    status: "Agendado",
    duracao: "30min",
  },
  {
    id: 5,
    crianca: "Ana Silva",
    terapeuta: "Dr. Maria Silva",
    responsavel: "Carlos Silva",
    data: "2024-01-28",
    horario: "15:00",
    tipo: "ABA",
    status: "Agendado",
    duracao: "1h",
  },
]

export default function AgendaPage() {
  const [mostrarFormulario, setMostrarFormulario] = useState(false)
  const [filtroNome, setFiltroNome] = useState("")
  const [filtroHorario, setFiltroHorario] = useState("")
  const [filtroResponsavel, setFiltroResponsavel] = useState("")
  const [filtroData, setFiltroData] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const agendamentosFiltrados = agendamentos.filter(agendamento => {
    const matchNome = filtroNome === "" || agendamento.crianca.toLowerCase().includes(filtroNome.toLowerCase())
    const matchHorario = filtroHorario === "" || agendamento.horario.includes(filtroHorario)
    const matchResponsavel = filtroResponsavel === "" || agendamento.responsavel.toLowerCase().includes(filtroResponsavel.toLowerCase())
    const matchData = filtroData === "" || agendamento.data === filtroData
    
    return matchNome && matchHorario && matchResponsavel && matchData
  })

  const handleAgendar = async () => {
    setIsLoading(true)
    await new Promise(resolve => setTimeout(resolve, 1000))
    alert("Agendamento criado com sucesso!")
    setMostrarFormulario(false)
    setIsLoading(false)
  }

  const handleCancelarAgendamento = (id: number) => {
    if (confirm("Tem certeza que deseja cancelar este agendamento?")) {
      alert(`Agendamento ${id} cancelado!`)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Voltar
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <Calendar className="h-6 w-6 text-primary" />
                <h1 className="text-xl font-bold">Agenda</h1>
              </div>
            </div>
            <Button onClick={() => setMostrarFormulario(!mostrarFormulario)}>
              <Plus className="h-4 w-4 mr-2" />
              Novo Agendamento
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Filtros */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Filtros</CardTitle>
            <CardDescription>Filtre os agendamentos por diferentes critérios</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input 
                  placeholder="Nome da criança..." 
                  className="pl-10" 
                  value={filtroNome}
                  onChange={(e) => setFiltroNome(e.target.value)}
                />
              </div>
              <Input 
                placeholder="Horário (ex: 09:00)" 
                value={filtroHorario}
                onChange={(e) => setFiltroHorario(e.target.value)}
              />
              <Input 
                placeholder="Responsável..." 
                value={filtroResponsavel}
                onChange={(e) => setFiltroResponsavel(e.target.value)}
              />
              <Input 
                type="date"
                value={filtroData}
                onChange={(e) => setFiltroData(e.target.value)}
              />
              <Button variant="outline" onClick={() => {
                setFiltroNome("")
                setFiltroHorario("")
                setFiltroResponsavel("")
                setFiltroData("")
              }}>
                <Filter className="h-4 w-4 mr-2" />
                Limpar
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Formulário de Agendamento */}
          {mostrarFormulario && (
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle>Novo Agendamento</CardTitle>
                  <CardDescription>Agende uma nova sessão</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="crianca">Criança</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione a criança" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ana">Ana Silva</SelectItem>
                        <SelectItem value="pedro">Pedro Santos</SelectItem>
                        <SelectItem value="sofia">Sofia Oliveira</SelectItem>
                        <SelectItem value="lucas">Lucas Costa</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="terapeuta">Terapeuta</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o terapeuta" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="maria">Dr. Maria Silva</SelectItem>
                        <SelectItem value="carla">Dra. Carla Oliveira</SelectItem>
                        <SelectItem value="roberto">Dr. Roberto Silva</SelectItem>
                        <SelectItem value="joao">Dra. João Santos</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="responsavel">Responsável</Label>
                    <Input id="responsavel" placeholder="Nome do responsável" />
                  </div>

                  <div>
                    <Label htmlFor="data">Data</Label>
                    <Input id="data" type="date" />
                  </div>

                  <div>
                    <Label htmlFor="horario">Horário</Label>
                    <Input id="horario" type="time" />
                  </div>

                  <div>
                    <Label htmlFor="tipo">Tipo de Sessão</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="aba">ABA</SelectItem>
                        <SelectItem value="social">Social</SelectItem>
                        <SelectItem value="comunicacao">Comunicação</SelectItem>
                        <SelectItem value="sensorial">Sensorial</SelectItem>
                        <SelectItem value="comportamental">Comportamental</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="duracao">Duração</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione a duração" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="30min">30 minutos</SelectItem>
                        <SelectItem value="45min">45 minutos</SelectItem>
                        <SelectItem value="1h">1 hora</SelectItem>
                        <SelectItem value="1h30min">1h 30min</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex gap-2 pt-4">
                    <Button 
                      className="flex-1" 
                      onClick={handleAgendar}
                      disabled={isLoading}
                    >
                      {isLoading ? "Agendando..." : "Agendar"}
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => setMostrarFormulario(false)}
                      className="flex-1"
                    >
                      Cancelar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Lista de Agendamentos */}
          <div className={mostrarFormulario ? "lg:col-span-2" : "lg:col-span-3"}>
            <Card>
              <CardHeader>
                <CardTitle>Agendamentos ({agendamentosFiltrados.length})</CardTitle>
                <CardDescription>Sessões agendadas</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {agendamentosFiltrados.map((agendamento) => (
                    <div key={agendamento.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="flex flex-col items-center text-center">
                            <div className="text-2xl font-bold text-primary">
                              {new Date(agendamento.data).getDate()}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {new Date(agendamento.data).toLocaleDateString("pt-BR", { 
                                month: "short" 
                              })}
                            </div>
                          </div>
                          
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-1">
                              <User className="h-4 w-4 text-muted-foreground" />
                              <span className="font-medium">{agendamento.crianca}</span>
                            </div>
                            <div className="flex items-center space-x-2 mb-1">
                              <Clock className="h-4 w-4 text-muted-foreground" />
                              <span className="text-sm text-muted-foreground">
                                {agendamento.horario} - {agendamento.duracao}
                              </span>
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {agendamento.terapeuta}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              Responsável: {agendamento.responsavel}
                            </div>
                          </div>
                        </div>

                        <div className="flex flex-col items-end space-y-2">
                          <Badge variant="outline">{agendamento.tipo}</Badge>
                          <Badge variant={
                            agendamento.status === "Confirmado" ? "default" : "secondary"
                          }>
                            {agendamento.status}
                          </Badge>
                          <Button 
                            variant="destructive" 
                            size="sm"
                            onClick={() => handleCancelarAgendamento(agendamento.id)}
                          >
                            <X className="h-4 w-4 mr-1" />
                            Cancelar
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {agendamentosFiltrados.length === 0 && (
                  <div className="text-center py-12">
                    <p className="text-muted-foreground">Nenhum agendamento encontrado.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
