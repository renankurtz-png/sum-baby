"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Search, Filter, Star, TrendingUp, Calendar, User } from 'lucide-react'
import Link from "next/link"

const avaliacoes = [
  {
    id: 1,
    crianca: "Ana Silva",
    terapeuta: "Dr. Maria Silva",
    data: "2024-01-20",
    tipo: "ABA",
    nota: 4.8,
    progresso: "Excelente",
    observacoes: "Ótimo desenvolvimento na comunicação funcional",
    areas: ["Comunicação", "Social", "Comportamental"],
  },
  {
    id: 2,
    crianca: "Pedro Santos",
    terapeuta: "Dra. Carla Oliveira",
    data: "2024-01-19",
    tipo: "Social",
    nota: 4.2,
    progresso: "Bom",
    observacoes: "Melhorias significativas na interação social",
    areas: ["Social", "Comunicação"],
  },
  {
    id: 3,
    crianca: "Sofia Oliveira",
    terapeuta: "Dr. Maria Silva",
    data: "2024-01-18",
    tipo: "Sensorial",
    nota: 4.6,
    progresso: "Muito Bom",
    observacoes: "Excelente regulação sensorial durante as atividades",
    areas: ["Sensorial", "Comportamental"],
  },
  {
    id: 4,
    crianca: "Lucas Costa",
    terapeuta: "Dr. Roberto Silva",
    data: "2024-01-17",
    tipo: "Comportamental",
    nota: 3.8,
    progresso: "Regular",
    observacoes: "Alguns desafios comportamentais, mas com progresso",
    areas: ["Comportamental", "Autonomia"],
  },
]

export default function AvaliacaoPage() {
  const [filtroNome, setFiltroNome] = useState("")
  const [filtroTipo, setFiltroTipo] = useState("")
  const [filtroProgresso, setFiltroProgresso] = useState("")
  const [filtroTerapeuta, setFiltroTerapeuta] = useState("")

  const avaliacoesFiltradas = avaliacoes.filter(avaliacao => {
    const matchNome = avaliacao.crianca.toLowerCase().includes(filtroNome.toLowerCase())
    const matchTipo = filtroTipo === "" || filtroTipo === "todos-tipos" || avaliacao.tipo === filtroTipo
    const matchProgresso = filtroProgresso === "" || filtroProgresso === "todos-progressos" || avaliacao.progresso === filtroProgresso
    const matchTerapeuta = filtroTerapeuta === "" || filtroTerapeuta === "todos-terapeutas" || avaliacao.terapeuta.includes(filtroTerapeuta)
    
    return matchNome && matchTipo && matchProgresso && matchTerapeuta
  })

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Voltar
                </Button>
              </Link>
              <div className="flex items-center space-x-2">
                <Star className="h-6 w-6 text-primary" />
                <h1 className="text-xl font-bold">Avaliações</h1>
              </div>
            </div>
            <Link href="/nova-avaliacao">
              <Button>
                <Star className="h-4 w-4 mr-2" />
                Nova Avaliação
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Filtros e Busca */}
        <div className="mb-8">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input 
                placeholder="Buscar por criança..." 
                className="pl-10" 
                value={filtroNome}
                onChange={(e) => setFiltroNome(e.target.value)}
              />
            </div>
            <Select value={filtroTipo} onValueChange={setFiltroTipo}>
              <SelectTrigger>
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos-tipos">Todos</SelectItem>
                <SelectItem value="ABA">ABA</SelectItem>
                <SelectItem value="Social">Social</SelectItem>
                <SelectItem value="Sensorial">Sensorial</SelectItem>
                <SelectItem value="Comportamental">Comportamental</SelectItem>
                <SelectItem value="Comunicação">Comunicação</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filtroProgresso} onValueChange={setFiltroProgresso}>
              <SelectTrigger>
                <SelectValue placeholder="Progresso" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos-progressos">Todos</SelectItem>
                <SelectItem value="Excelente">Excelente</SelectItem>
                <SelectItem value="Muito Bom">Muito Bom</SelectItem>
                <SelectItem value="Bom">Bom</SelectItem>
                <SelectItem value="Regular">Regular</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filtroTerapeuta} onValueChange={setFiltroTerapeuta}>
              <SelectTrigger>
                <SelectValue placeholder="Terapeuta" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos-terapeutas">Todos</SelectItem>
                <SelectItem value="Maria">Dr. Maria Silva</SelectItem>
                <SelectItem value="Carla">Dra. Carla Oliveira</SelectItem>
                <SelectItem value="Roberto">Dr. Roberto Silva</SelectItem>
                <SelectItem value="Joao">Dra. João Santos</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" onClick={() => {
              setFiltroNome("")
              setFiltroTipo("todos-tipos")
              setFiltroProgresso("todos-progressos")
              setFiltroTerapeuta("todos-terapeutas")
            }}>
              <Filter className="h-4 w-4 mr-2" />
              Limpar
            </Button>
          </div>
        </div>

        {/* Lista de Avaliações */}
        <div className="space-y-4">
          {avaliacoesFiltradas.map((avaliacao) => (
            <Card key={avaliacao.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-2">
                          <User className="h-4 w-4 text-muted-foreground" />
                          <span className="font-semibold">{avaliacao.crianca}</span>
                        </div>
                        <Badge variant="outline">{avaliacao.tipo}</Badge>
                      </div>
                      
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
                          <span className="font-semibold">{avaliacao.nota}</span>
                        </div>
                        <Badge variant={
                          avaliacao.progresso === "Excelente" ? "default" :
                          avaliacao.progresso === "Muito Bom" ? "default" :
                          avaliacao.progresso === "Bom" ? "secondary" : "outline"
                        }>
                          <TrendingUp className="h-3 w-3 mr-1" />
                          {avaliacao.progresso}
                        </Badge>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <p className="text-sm text-muted-foreground">{avaliacao.observacoes}</p>
                      
                      <div className="flex flex-wrap gap-1">
                        {avaliacao.areas.map((area, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {area}
                          </Badge>
                        ))}
                      </div>

                      <div className="flex items-center justify-between text-sm text-muted-foreground pt-2">
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-1" />
                          {new Date(avaliacao.data).toLocaleDateString("pt-BR")}
                        </div>
                        <div>
                          {avaliacao.terapeuta}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col justify-center">
                    <Button variant="outline" size="sm">
                      Ver Detalhes
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {avaliacoesFiltradas.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Nenhuma avaliação encontrada com os filtros aplicados.</p>
          </div>
        )}
      </div>
    </div>
  )
}
