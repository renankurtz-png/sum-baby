import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, Eye, Calendar, Plus, ImageIcon, Video } from 'lucide-react'
import Link from "next/link"

// Dados de exemplo
const avaliacoes = [
  {
    id: 1,
    titulo: "Terapia de Comunicação",
    categoria: "ABA",
    nota: 4.5,
    descricao: "Excelente progresso na comunicação funcional da criança",
    imagem: "/placeholder.svg?height=200&width=300",
    visitas: 245,
    data: "2024-01-15",
    hasVideo: true,
  },
  {
    id: 2,
    titulo: "Desenvolvimento Social",
    categoria: "Terapia",
    nota: 5.0,
    descricao: "Melhora significativa nas habilidades sociais e interação",
    imagem: "/placeholder.svg?height=200&width=300",
    visitas: 189,
    data: "2024-01-12",
    hasVideo: false,
  },
  {
    id: 3,
    titulo: "Integração Sensorial",
    categoria: "Especializada",
    nota: 4.2,
    descricao: "Ótimos resultados na regulação sensorial da criança",
    imagem: "/placeholder.svg?height=200&width=300",
    visitas: 156,
    data: "2024-01-10",
    hasVideo: true,
  },
]

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Star className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold">Sun Baby</h1>
            </div>
            <nav className="hidden md:flex items-center space-x-6">
              <Link href="/" className="text-foreground hover:text-primary">
                Início
              </Link>
              <Link href="/criancas" className="text-muted-foreground hover:text-primary">
                Crianças
              </Link>
              <Link href="/atividades" className="text-muted-foreground hover:text-primary">
                Atividades
              </Link>
              <Link href="/agenda" className="text-muted-foreground hover:text-primary">
                Agenda
              </Link>
              <Link href="/atendimento" className="text-muted-foreground hover:text-primary">
                Atendimento
              </Link>
              <Link href="/avaliacao" className="text-muted-foreground hover:text-primary">
                Avaliação
              </Link>
              <Link href="/admin" className="text-muted-foreground hover:text-primary">
                Admin
              </Link>
            </nav>
            <Link href="/nova-avaliacao">
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Nova Avaliação
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary/10 to-secondary/10 py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-4">Cuidado especializado para cada criança</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Acompanhe o desenvolvimento individual de cada criança com terapia ABA personalizada 
            e registre a evolução de forma detalhada.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/nova-avaliacao">
              <Button size="lg">Avaliar Serviço</Button>
            </Link>
            <Link href="/atividades">
              <Button variant="outline" size="lg">
                Ver Terapias
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Avaliações Recentes */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-3xl font-bold">Avaliações Recentes</h3>
            <Link href="/todas-avaliacoes">
              <Button variant="outline">Ver Todas</Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {avaliacoes.map((avaliacao) => (
              <Card key={avaliacao.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative">
                  <img
                    src={avaliacao.imagem || "/placeholder.svg"}
                    alt={avaliacao.titulo}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute top-2 right-2 flex gap-1">
                    <Badge variant="secondary" className="bg-white/90">
                      <ImageIcon className="h-3 w-3 mr-1" />
                      Foto
                    </Badge>
                    {avaliacao.hasVideo && (
                      <Badge variant="secondary" className="bg-white/90">
                        <Video className="h-3 w-3 mr-1" />
                        Vídeo
                      </Badge>
                    )}
                  </div>
                </div>

                <CardHeader>
                  <div className="flex items-center justify-between">
                    <Badge variant="outline">{avaliacao.categoria}</Badge>
                    <div className="flex items-center">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
                      <span className="font-semibold">{avaliacao.nota}</span>
                    </div>
                  </div>
                  <CardTitle className="text-lg">{avaliacao.titulo}</CardTitle>
                  <CardDescription>{avaliacao.descricao}</CardDescription>
                </CardHeader>

                <CardContent>
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <div className="flex items-center">
                      <Eye className="h-4 w-4 mr-1" />
                      {avaliacao.visitas} visitas
                    </div>
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      {new Date(avaliacao.data).toLocaleDateString("pt-BR")}
                    </div>
                  </div>
                  <Button className="w-full mt-4 bg-transparent" variant="outline">
                    Ver Detalhes
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-muted py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Star className="h-6 w-6 text-primary" />
                <span className="text-lg font-bold">Sun Baby</span>
              </div>
              <p className="text-muted-foreground">
                Especializada em terapia ABA para desenvolvimento infantil.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Navegação</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li>
                  <Link href="/" className="hover:text-primary">
                    Início
                  </Link>
                </li>
                <li>
                  <Link href="/atividades" className="hover:text-primary">
                    Atividades
                  </Link>
                </li>
                <li>
                  <Link href="/visitas" className="hover:text-primary">
                    Visitas
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Categorias</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li>
                  <Link href="#" className="hover:text-primary">
                    Terapia ABA
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-primary">
                    Desenvolvimento
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-primary">
                    Especializada
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Suporte</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li>
                  <Link href="#" className="hover:text-primary">
                    Ajuda
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-primary">
                    Contato
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-primary">
                    Termos
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t mt-8 pt-8 text-center text-muted-foreground">
            <p>&copy; 2024 AvaliaçõesBR. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
