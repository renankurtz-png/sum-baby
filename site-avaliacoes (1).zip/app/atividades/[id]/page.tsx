"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Edit, Save, X, Upload, Video, Image } from 'lucide-react'
import Link from "next/link"

const atividade = {
  id: 1,
  titulo: "Sessão de Comunicação Funcional",
  categoria: "Comunicação",
  crianca: "Ana Silva",
  data: "2024-01-20",
  participantes: 1,
  descricao: "Desenvolvimento de habilidades de comunicação através de PECS e sinais",
  imagem: "/placeholder.svg?height=300&width=400",
  objetivos: [
    "Aumentar repertório de mandos",
    "Melhorar contato visual",
    "Desenvolver comunicação funcional"
  ],
  materiais: ["PECS", "Cartões visuais", "Brinquedos motivadores"],
  resultados: "Criança demonstrou progresso significativo na comunicação",
  proximaEtapa: "Expandir vocabulário de mandos"
}

export default function DetalheAtividadePage({ params }: { params: { id: string } }) {
  const [editando, setEditando] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [fotos, setFotos] = useState<string[]>([])
  const [videos, setVideos] = useState<string[]>([])

  const handleSalvar = async () => {
    setIsLoading(true)
    await new Promise(resolve => setTimeout(resolve, 1000))
    alert("Atividade atualizada com sucesso!")
    setEditando(false)
    setIsLoading(false)
  }

  const handleFotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files) {
      const newFotos = Array.from(files).map((file) => URL.createObjectURL(file))
      setFotos([...fotos, ...newFotos])
    }
  }

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files) {
      const newVideos = Array.from(files).map((file) => URL.createObjectURL(file))
      setVideos([...videos, ...newVideos])
    }
  }

  const removeFoto = (index: number) => {
    setFotos(fotos.filter((_, i) => i !== index))
  }

  const removeVideo = (index: number) => {
    setVideos(videos.filter((_, i) => i !== index))
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/atividades">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Voltar
                </Button>
              </Link>
              <h1 className="text-xl font-bold">Detalhes da Atividade</h1>
            </div>
            <div className="flex gap-2">
              {!editando ? (
                <Button onClick={() => setEditando(true)}>
                  <Edit className="h-4 w-4 mr-2" />
                  Editar
                </Button>
              ) : (
                <>
                  <Button onClick={handleSalvar} disabled={isLoading}>
                    <Save className="h-4 w-4 mr-2" />
                    {isLoading ? "Salvando..." : "Salvar"}
                  </Button>
                  <Button variant="outline" onClick={() => setEditando(false)}>
                    <X className="h-4 w-4 mr-2" />
                    Cancelar
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Informações da Atividade */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <Badge variant="outline">{atividade.categoria}</Badge>
                  <span className="text-sm text-muted-foreground">
                    {new Date(atividade.data).toLocaleDateString("pt-BR")}
                  </span>
                </div>
                <CardTitle className="text-2xl">{atividade.titulo}</CardTitle>
                <CardDescription>Criança: {atividade.crianca}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {editando ? (
                  <>
                    <div>
                      <Label htmlFor="titulo">Título</Label>
                      <Input id="titulo" defaultValue={atividade.titulo} />
                    </div>
                    <div>
                      <Label htmlFor="descricao">Descrição</Label>
                      <Textarea id="descricao" defaultValue={atividade.descricao} rows={3} />
                    </div>
                    <div>
                      <Label htmlFor="categoria">Categoria</Label>
                      <Select defaultValue={atividade.categoria}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Comunicação">Comunicação</SelectItem>
                          <SelectItem value="Social">Social</SelectItem>
                          <SelectItem value="Comportamental">Comportamental</SelectItem>
                          <SelectItem value="Sensorial">Sensorial</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                ) : (
                  <>
                    <p className="text-muted-foreground">{atividade.descricao}</p>
                    <div>
                      <h4 className="font-semibold mb-2">Objetivos:</h4>
                      <ul className="list-disc list-inside space-y-1">
                        {atividade.objetivos.map((objetivo, index) => (
                          <li key={index} className="text-sm text-muted-foreground">{objetivo}</li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Materiais:</h4>
                      <div className="flex flex-wrap gap-2">
                        {atividade.materiais.map((material, index) => (
                          <Badge key={index} variant="secondary">{material}</Badge>
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            {/* Resultados */}
            <Card>
              <CardHeader>
                <CardTitle>Resultados e Próximas Etapas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {editando ? (
                  <>
                    <div>
                      <Label htmlFor="resultados">Resultados</Label>
                      <Textarea id="resultados" defaultValue={atividade.resultados} rows={3} />
                    </div>
                    <div>
                      <Label htmlFor="proximaEtapa">Próxima Etapa</Label>
                      <Textarea id="proximaEtapa" defaultValue={atividade.proximaEtapa} rows={2} />
                    </div>
                  </>
                ) : (
                  <>
                    <div>
                      <h4 className="font-semibold mb-2">Resultados:</h4>
                      <p className="text-sm text-muted-foreground">{atividade.resultados}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Próxima Etapa:</h4>
                      <p className="text-sm text-muted-foreground">{atividade.proximaEtapa}</p>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Mídia e Documentos */}
          <div className="space-y-6">
            {/* Imagem Principal */}
            <Card>
              <CardHeader>
                <CardTitle>Imagem Principal</CardTitle>
              </CardHeader>
              <CardContent>
                <img
                  src={atividade.imagem || "/placeholder.svg"}
                  alt={atividade.titulo}
                  className="w-full h-64 object-cover rounded-lg"
                />
              </CardContent>
            </Card>

            {/* Upload de Fotos */}
            <Card>
              <CardHeader>
                <CardTitle>Fotos da Sessão</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-4 text-center">
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={handleFotoUpload}
                    className="hidden"
                    id="foto-upload"
                  />
                  <label htmlFor="foto-upload" className="cursor-pointer">
                    <Upload className="h-6 w-6 mx-auto mb-2 text-muted-foreground" />
                    <p className="text-sm text-muted-foreground">Adicionar fotos</p>
                  </label>
                </div>

                {fotos.length > 0 && (
                  <div className="grid grid-cols-2 gap-4">
                    {fotos.map((foto, index) => (
                      <div key={index} className="relative">
                        <img
                          src={foto || "/placeholder.svg"}
                          alt={`Foto ${index + 1}`}
                          className="w-full h-24 object-cover rounded-lg"
                        />
                        <button
                          onClick={() => removeFoto(index)}
                          className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1"
                        >
                          <X className="h-3 w-3" />
                        </button>
                        <Badge className="absolute bottom-1 left-1" variant="secondary">
                          <Image className="h-3 w-3 mr-1" />
                          Foto
                        </Badge>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Upload de Vídeos */}
            <Card>
              <CardHeader>
                <CardTitle>Vídeos da Sessão</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-4 text-center">
                  <input
                    type="file"
                    multiple
                    accept="video/*"
                    onChange={handleVideoUpload}
                    className="hidden"
                    id="video-upload"
                  />
                  <label htmlFor="video-upload" className="cursor-pointer">
                    <Video className="h-6 w-6 mx-auto mb-2 text-muted-foreground" />
                    <p className="text-sm text-muted-foreground">Adicionar vídeos</p>
                  </label>
                </div>

                {videos.length > 0 && (
                  <div className="space-y-4">
                    {videos.map((video, index) => (
                      <div key={index} className="relative">
                        <video src={video} className="w-full h-32 object-cover rounded-lg" controls />
                        <button
                          onClick={() => removeVideo(index)}
                          className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1"
                        >
                          <X className="h-3 w-3" />
                        </button>
                        <Badge className="absolute bottom-1 left-1" variant="secondary">
                          <Video className="h-3 w-3 mr-1" />
                          Vídeo
                        </Badge>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
