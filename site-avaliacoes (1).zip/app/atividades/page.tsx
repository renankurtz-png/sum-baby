"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Search, Filter, Calendar, Users, Brain, User } from 'lucide-react'
import Link from "next/link"
import { useState } from "react"

const atividades = [
  {
    id: 1,
    titulo: "Sessão de Comunicação Funcional",
    categoria: "Comunicação",
    crianca: "Ana Silva",
    data: "2024-01-20",
    participantes: 1,
    descricao: "Desenvolvimento de habilidades de comunicação através de PECS e sinais",
    imagem: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 2,
    titulo: "Treino de Habilidades Sociais",
    categoria: "Social",
    crianca: "Pedro Santos",
    data: "2024-01-22",
    participantes: 3,
    descricao: "Atividades em grupo para desenvolver interação social e cooperação",
    imagem: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 3,
    titulo: "Intervenção Comportamental Intensiva",
    categoria: "Comportamental",
    crianca: "Sofia Oliveira",
    data: "2024-01-25",
    participantes: 1,
    descricao: "Sessão individual focada em redução de comportamentos desafiadores",
    imagem: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 4,
    titulo: "Desenvolvimento de Autonomia",
    categoria: "Vida Diária",
    crianca: "Lucas Costa",
    data: "2024-01-28",
    participantes: 2,
    descricao: "Treino de habilidades de vida diária e independência pessoal",
    imagem: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 5,
    titulo: "Terapia de Integração Sensorial",
    categoria: "Sensorial",
    crianca: "Ana Silva",
    data: "2024-01-30",
    participantes: 1,
    descricao: "Atividades para regulação sensorial e processamento de estímulos",
    imagem: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 6,
    titulo: "Programa de Inclusão Escolar",
    categoria: "Educacional",
    crianca: "Pedro Santos",
    data: "2024-02-02",
    participantes: 5,
    descricao: "Suporte para adaptação e participação no ambiente escolar",
    imagem: "/placeholder.svg?height=200&width=300",
  },
]

export default function AtividadesPage() {
  const [filtroCrianca, setFiltroCrianca] = useState("todas-criancas")
  const [filtroCategoria, setFiltroCategoria] = useState("todas-categorias")

  const atividadesFiltradas = atividades.filter(atividade => {
    const matchCrianca = filtroCrianca === "todas-criancas" || atividade.crianca === filtroCrianca
    const matchCategoria = filtroCategoria === "todas-categorias" || atividade.categoria === filtroCategoria
    return matchCrianca && matchCategoria
  })

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar
              </Button>
            </Link>
            <div className="flex items-center space-x-2">
              <Brain className="h-6 w-6 text-primary" />
              <h1 className="text-xl font-bold">Intervenções ABA</h1>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Filtros e Busca */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input placeholder="Buscar intervenções ABA..." className="pl-10" />
              </div>
            </div>
            <Select value={filtroCategoria} onValueChange={setFiltroCategoria}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Categoria" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas-categorias">Todas</SelectItem>
                <SelectItem value="Comunicação">Comunicação</SelectItem>
                <SelectItem value="Social">Social</SelectItem>
                <SelectItem value="Comportamental">Comportamental</SelectItem>
                <SelectItem value="Vida Diária">Vida Diária</SelectItem>
                <SelectItem value="Sensorial">Sensorial</SelectItem>
                <SelectItem value="Educacional">Educacional</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filtroCrianca} onValueChange={setFiltroCrianca}>
              <SelectTrigger>
                <SelectValue placeholder="Criança" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas-criancas">Todas</SelectItem>
                <SelectItem value="Ana Silva">Ana Silva</SelectItem>
                <SelectItem value="Pedro Santos">Pedro Santos</SelectItem>
                <SelectItem value="Sofia Oliveira">Sofia Oliveira</SelectItem>
                <SelectItem value="Lucas Costa">Lucas Costa</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" onClick={() => {
              setFiltroCategoria("todas-categorias")
              setFiltroCrianca("todas-criancas")
            }}>
              <Filter className="h-4 w-4 mr-2" />
              Limpar
            </Button>
          </div>
        </div>

        {/* Lista de Atividades */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {atividadesFiltradas.map((atividade) => (
            <Card key={atividade.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative">
                <img
                  src={atividade.imagem || "/placeholder.svg"}
                  alt={atividade.titulo}
                  className="w-full h-48 object-cover"
                />
                <div className="absolute top-2 left-2">
                  <Badge variant="secondary" className="bg-white/90">
                    {atividade.categoria}
                  </Badge>
                </div>
              </div>

              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Users className="h-4 w-4 mr-1" />
                    {atividade.participantes} vagas
                  </div>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <User className="h-4 w-4 mr-1" />
                    {atividade.crianca}
                  </div>
                </div>
                <CardTitle className="text-lg">{atividade.titulo}</CardTitle>
                <CardDescription>{atividade.descricao}</CardDescription>
                <div className="text-sm text-muted-foreground mt-2">
                  <p><strong>Objetivos:</strong> Desenvolver comunicação funcional</p>
                  <p><strong>Materiais:</strong> PECS, cartões visuais</p>
                </div>
              </CardHeader>

              <CardContent>
                <div className="space-y-2 mb-4">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4 mr-2" />
                    {new Date(atividade.data).toLocaleDateString("pt-BR")}
                  </div>
                </div>
                <Link href={`/atividades/${atividade.id}`}>
                  <Button className="w-full">Ver Detalhes</Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        {atividadesFiltradas.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Nenhuma atividade encontrada com os filtros aplicados.</p>
          </div>
        )}

        {/* Paginação */}
        <div className="flex justify-center mt-12">
          <div className="flex items-center space-x-2">
            <Button variant="outline" disabled>
              Anterior
            </Button>
            <Button variant="outline" className="bg-primary text-primary-foreground">
              1
            </Button>
            <Button variant="outline">2</Button>
            <Button variant="outline">3</Button>
            <Button variant="outline">Próximo</Button>
          </div>
        </div>
      </div>
    </div>
  )
}
