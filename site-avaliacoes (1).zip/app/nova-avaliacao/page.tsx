"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Star, Upload, X, ImageIcon, VideoIcon, ArrowLeft } from 'lucide-react'
import Link from "next/link"

export default function NovaAvaliacaoPage() {
  const [nota, setNota] = useState(0)
  const [hoverNota, setHoverNota] = useState(0)
  const [imagens, setImagens] = useState<string[]>([])
  const [videos, setVideos] = useState<string[]>([])
  const [isLoading, setIsLoading] = useState(false)

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files) {
      const newImages = Array.from(files).map((file) => URL.createObjectURL(file))
      setImagens([...imagens, ...newImages])
    }
  }

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files) {
      const newVideos = Array.from(files).map((file) => URL.createObjectURL(file))
      setVideos([...videos, ...newVideos])
    }
  }

  const removeImage = (index: number) => {
    setImagens(imagens.filter((_, i) => i !== index))
  }

  const removeVideo = (index: number) => {
    setVideos(videos.filter((_, i) => i !== index))
  }

  const handlePublicar = async () => {
    setIsLoading(true)
    // Simular salvamento
    await new Promise(resolve => setTimeout(resolve, 1000))
    alert("Avaliação publicada com sucesso!")
    setIsLoading(false)
  }

  const handleSalvarRascunho = async () => {
    setIsLoading(true)
    await new Promise(resolve => setTimeout(resolve, 1000))
    alert("Rascunho salvo com sucesso!")
    setIsLoading(false)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar
              </Button>
            </Link>
            <div className="flex items-center space-x-2">
              <Star className="h-6 w-6 text-primary" />
              <h1 className="text-xl font-bold">Nova Avaliação</h1>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Criar Nova Avaliação</CardTitle>
              <CardDescription>Avalie nossos serviços de terapia e desenvolvimento infantil</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Informações Básicas */}
              <div className="space-y-4">
                <div>
                  <Label htmlFor="titulo">Título da Avaliação</Label>
                  <Input id="titulo" placeholder="Ex: Sessão de Terapia ABA" />
                </div>

                <div>
                  <Label htmlFor="categoria">Categoria</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione uma categoria" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="terapia-aba">Terapia ABA</SelectItem>
                      <SelectItem value="desenvolvimento">Desenvolvimento</SelectItem>
                      <SelectItem value="comunicacao">Comunicação</SelectItem>
                      <SelectItem value="social">Social</SelectItem>
                      <SelectItem value="sensorial">Sensorial</SelectItem>
                      <SelectItem value="comportamental">Comportamental</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="localizacao">Localização</Label>
                  <Input id="localizacao" placeholder="Sala de Terapia, Andar" />
                </div>
              </div>

              {/* Avaliação com Estrelas */}
              <div>
                <Label>Sua Avaliação</Label>
                <div className="flex items-center space-x-1 mt-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      className="focus:outline-none"
                      onMouseEnter={() => setHoverNota(star)}
                      onMouseLeave={() => setHoverNota(0)}
                      onClick={() => setNota(star)}
                    >
                      <Star
                        className={`h-8 w-8 ${
                          star <= (hoverNota || nota) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                        }`}
                      />
                    </button>
                  ))}
                  <span className="ml-2 text-sm text-muted-foreground">{nota > 0 && `${nota}/5 estrelas`}</span>
                </div>
              </div>

              {/* Descrição */}
              <div>
                <Label htmlFor="descricao">Descrição</Label>
                <Textarea id="descricao" placeholder="Conte sobre sua experiência..." rows={4} />
              </div>

              {/* Upload de Imagens */}
              <div>
                <Label>Imagens</Label>
                <div className="mt-2">
                  <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-6 text-center">
                    <input
                      type="file"
                      multiple
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                      id="image-upload"
                    />
                    <label htmlFor="image-upload" className="cursor-pointer">
                      <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground">Clique para adicionar imagens ou arraste aqui</p>
                    </label>
                  </div>

                  {imagens.length > 0 && (
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-4">
                      {imagens.map((img, index) => (
                        <div key={index} className="relative">
                          <img
                            src={img || "/placeholder.svg"}
                            alt={`Upload ${index + 1}`}
                            className="w-full h-24 object-cover rounded-lg"
                          />
                          <button
                            onClick={() => removeImage(index)}
                            className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1"
                          >
                            <X className="h-3 w-3" />
                          </button>
                          <Badge className="absolute bottom-1 left-1" variant="secondary">
                            <ImageIcon className="h-3 w-3 mr-1" />
                            Foto
                          </Badge>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Upload de Vídeos */}
              <div>
                <Label>Vídeos</Label>
                <div className="mt-2">
                  <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-6 text-center">
                    <input
                      type="file"
                      multiple
                      accept="video/*"
                      onChange={handleVideoUpload}
                      className="hidden"
                      id="video-upload"
                    />
                    <label htmlFor="video-upload" className="cursor-pointer">
                      <VideoIcon className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground">Clique para adicionar vídeos ou arraste aqui</p>
                    </label>
                  </div>

                  {videos.length > 0 && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                      {videos.map((video, index) => (
                        <div key={index} className="relative">
                          <video src={video} className="w-full h-32 object-cover rounded-lg" controls />
                          <button
                            onClick={() => removeVideo(index)}
                            className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1"
                          >
                            <X className="h-3 w-3" />
                          </button>
                          <Badge className="absolute bottom-1 left-1" variant="secondary">
                            <VideoIcon className="h-3 w-3 mr-1" />
                            Vídeo
                          </Badge>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Botões de Ação */}
              <div className="flex gap-4 pt-4">
                <Button 
                  className="flex-1" 
                  onClick={handlePublicar}
                  disabled={isLoading}
                >
                  {isLoading ? "Publicando..." : "Publicar Avaliação"}
                </Button>
                <Button 
                  variant="outline" 
                  className="flex-1" 
                  onClick={handleSalvarRascunho}
                  disabled={isLoading}
                >
                  {isLoading ? "Salvando..." : "Salvar Rascunho"}
                </Button>
                <Link href="/">
                  <Button variant="destructive" className="flex-1">
                    Cancelar
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
