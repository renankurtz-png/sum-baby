"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Clock, User, Calendar, FileText, Save } from 'lucide-react'
import Link from "next/link"

const atendimentosHoje = [
  {
    id: 1,
    crianca: "Ana Silva",
    horario: "09:00",
    tipo: "ABA",
    terapeuta: "Dr. Maria Silva",
    status: "Em Andamento",
    duracao: "1h",
  },
  {
    id: 2,
    crianca: "Pedro Santos",
    horario: "10:30",
    tipo: "Social",
    terapeuta: "Dra. Carla Oliveira",
    status: "Agendado",
    duracao: "45min",
  },
  {
    id: 3,
    crianca: "Sofia Oliveira",
    horario: "14:00",
    tipo: "Comunicação",
    terapeuta: "Dr. Maria Silva",
    status: "Agendado",
    duracao: "1h",
  },
]

export default function AtendimentoPage() {
  const [atendimentoSelecionado, setAtendimentoSelecionado] = useState<number | null>(null)
  const [observacoes, setObservacoes] = useState("")
  const [progresso, setProgresso] = useState("")

  const iniciarAtendimento = (id: number) => {
    setAtendimentoSelecionado(id)
  }

  const finalizarAtendimento = () => {
    // Aqui salvaria os dados do atendimento
    setAtendimentoSelecionado(null)
    setObservacoes("")
    setProgresso("")
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Voltar
              </Button>
            </Link>
            <div className="flex items-center space-x-2">
              <FileText className="h-6 w-6 text-primary" />
              <h1 className="text-xl font-bold">Atendimento</h1>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Lista de Atendimentos do Dia */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="h-5 w-5 mr-2" />
                  Hoje - {new Date().toLocaleDateString("pt-BR")}
                </CardTitle>
                <CardDescription>Atendimentos agendados</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {atendimentosHoje.map((atendimento) => (
                    <div 
                      key={atendimento.id} 
                      className={`border rounded-lg p-3 cursor-pointer transition-colors ${
                        atendimentoSelecionado === atendimento.id 
                          ? "border-primary bg-primary/5" 
                          : "hover:bg-muted/50"
                      }`}
                      onClick={() => iniciarAtendimento(atendimento.id)}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium">{atendimento.horario}</span>
                        </div>
                        <Badge variant={
                          atendimento.status === "Em Andamento" ? "default" : "secondary"
                        }>
                          {atendimento.status}
                        </Badge>
                      </div>
                      
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <User className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm">{atendimento.crianca}</span>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {atendimento.tipo} - {atendimento.duracao}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {atendimento.terapeuta}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Formulário de Atendimento */}
          <div className="lg:col-span-2">
            {atendimentoSelecionado ? (
              <Card>
                <CardHeader>
                  <CardTitle>Registro de Atendimento</CardTitle>
                  <CardDescription>
                    {atendimentosHoje.find(a => a.id === atendimentoSelecionado)?.crianca} - 
                    {atendimentosHoje.find(a => a.id === atendimentoSelecionado)?.tipo}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Informações da Sessão */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label>Horário de Início</Label>
                      <Input type="time" defaultValue="09:00" />
                    </div>
                    <div>
                      <Label>Horário de Término</Label>
                      <Input type="time" />
                    </div>
                    <div>
                      <Label>Duração Real</Label>
                      <Input placeholder="Ex: 55min" />
                    </div>
                  </div>

                  {/* Atividades Realizadas */}
                  <div>
                    <Label>Atividades Realizadas</Label>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-2">
                      {[
                        "Comunicação Funcional",
                        "Imitação",
                        "Seguimento de Instruções",
                        "Interação Social",
                        "Regulação Sensorial",
                        "Autonomia",
                        "Comportamento Adaptativo",
                        "Habilidades Acadêmicas"
                      ].map((atividade) => (
                        <label key={atividade} className="flex items-center space-x-2">
                          <input type="checkbox" className="rounded" />
                          <span className="text-sm">{atividade}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Progresso da Sessão */}
                  <div>
                    <Label htmlFor="progresso">Progresso da Sessão</Label>
                    <Select value={progresso} onValueChange={setProgresso}>
                      <SelectTrigger>
                        <SelectValue placeholder="Avalie o progresso geral" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="excelente">Excelente</SelectItem>
                        <SelectItem value="muito-bom">Muito Bom</SelectItem>
                        <SelectItem value="bom">Bom</SelectItem>
                        <SelectItem value="regular">Regular</SelectItem>
                        <SelectItem value="dificuldades">Com Dificuldades</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Objetivos Trabalhados */}
                  <div>
                    <Label>Objetivos Trabalhados</Label>
                    <div className="space-y-2 mt-2">
                      {[
                        "Aumentar repertório de mandos",
                        "Melhorar contato visual",
                        "Reduzir comportamentos repetitivos",
                        "Desenvolver brincadeira funcional"
                      ].map((objetivo, index) => (
                        <div key={index} className="flex items-center justify-between p-2 border rounded">
                          <span className="text-sm">{objetivo}</span>
                          <Select>
                            <SelectTrigger className="w-32">
                              <SelectValue placeholder="Status" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="atingido">Atingido</SelectItem>
                              <SelectItem value="progresso">Em Progresso</SelectItem>
                              <SelectItem value="iniciado">Iniciado</SelectItem>
                              <SelectItem value="nao-trabalhado">Não Trabalhado</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Observações */}
                  <div>
                    <Label htmlFor="observacoes">Observações Detalhadas</Label>
                    <Textarea
                      id="observacoes"
                      placeholder="Descreva o comportamento da criança, estratégias utilizadas, dificuldades encontradas, sucessos alcançados..."
                      rows={4}
                      value={observacoes}
                      onChange={(e) => setObservacoes(e.target.value)}
                    />
                  </div>

                  {/* Recomendações */}
                  <div>
                    <Label htmlFor="recomendacoes">Recomendações para Próxima Sessão</Label>
                    <Textarea
                      id="recomendacoes"
                      placeholder="Estratégias a serem mantidas, objetivos para próxima sessão, orientações para família..."
                      rows={3}
                    />
                  </div>

                  {/* Botões de Ação */}
                  <div className="flex gap-4 pt-4">
                    <Button onClick={finalizarAtendimento} className="flex-1">
                      <Save className="h-4 w-4 mr-2" />
                      Finalizar Atendimento
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => setAtendimentoSelecionado(null)}
                      className="flex-1"
                    >
                      Cancelar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="flex items-center justify-center h-64">
                  <div className="text-center">
                    <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">
                      Selecione um atendimento para iniciar o registro
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
